$("input#addItem").keypress(function (event) {
  if (event.which === 13) {
    if ($(this).val() === "") return;
    $("ul").prepend(
      '<li class="item mt-2 d-flex justify-content-between align-content-center"><span class="edit handler"><i class="fas fa-pen"></i></span><span class="text">' +
       $(this).val() +'</span><input class="editor" type="text"><span class="remove handler"><i class="fas fa-trash"></i></span></li>'
    );
    $(this).val('');
  }
});

$('.fa-plus').on('click', function () {
    $('input#addItem').slideToggle(100);
})


$('li.item').on('click', 'span.text',function(event){
    $(this).toggleClass("completed")
})

$('li.item').on('mouseenter',function () {
    
    $(this).children('.handler').animate({
       width: "80px",
       opacity:"1"
    })
})
$('li.item').on('mouseleave',function () {
    
    $(this).children('.handler').animate({
       width: "0",
       opacity:"0"
    })
})

$('li.item').on('click','span.remove',function () {
  $(this).parent().remove()
})

$('li.item').on('click','span.edit',function () {
  txt = $(this).parent().children('span.text');
  txt.fadeOut(200, function () {
    inputeditor = $(this).parent().children('input.editor')
    inputeditor.fadeIn(200,function(){
      inputeditor.val(txt.text())
    })
  })

})

$('input.editor').keypress(function (event) {
    if(event.which===13){
      val = $(this).val()
      $(this).fadeOut(200, function(){
       txt = $(this).parent().children('span.text');
       txt.text(val);
       txt.fadeIn(200);
      })
    }
})